package indevo.industries.changeling.script;

public interface CampaignNotificationMessager {
    void showMessage();
}
