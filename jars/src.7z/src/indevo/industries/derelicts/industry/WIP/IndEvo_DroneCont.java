package industrialevolution.industries.derelicts.industry;


//terraforms the entire system, needs continous stream of parts dropped by derelicts (commodity)
//quest things
//allow prioritizing planets
//slowly fix it over the course of a year (remove negative, apply positive conditions, change look)
//can switch planet
//Visual "terraforming stations" hovering the planet
//have them build shades/mirrors

public class IndEvo_DroneCont {
}
