package indevo.industries.petshop.listener;

public interface PetStatusListenerAPI {
    void reportPetTakingFood();

    void reportPetDied();

    void reportPetStarving();
}
